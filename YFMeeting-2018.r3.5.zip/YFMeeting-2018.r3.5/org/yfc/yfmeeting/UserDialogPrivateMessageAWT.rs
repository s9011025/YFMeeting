org.litesoft.p2pchat.UserDialogPrivateMessageAWT$2
org.litesoft.p2pchat.UserDialogPrivateMessageAWT
org.litesoft.p2pchat.UserDialogPrivateMessageAWT$1
