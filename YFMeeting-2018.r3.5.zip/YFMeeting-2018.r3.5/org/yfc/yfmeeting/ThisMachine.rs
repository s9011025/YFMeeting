org.litesoft.p2pchat.ThisMachine
