org.litesoft.p2pchat.MyInfo
