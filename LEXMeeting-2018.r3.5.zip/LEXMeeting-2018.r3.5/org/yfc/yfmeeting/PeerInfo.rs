org.litesoft.p2pchat.PeerInfo
