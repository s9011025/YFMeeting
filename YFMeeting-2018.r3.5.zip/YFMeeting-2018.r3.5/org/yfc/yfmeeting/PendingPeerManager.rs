org.litesoft.p2pchat.PendingPeerManager
org.litesoft.p2pchat.PendingPeerManager$ActivePeersSupport
