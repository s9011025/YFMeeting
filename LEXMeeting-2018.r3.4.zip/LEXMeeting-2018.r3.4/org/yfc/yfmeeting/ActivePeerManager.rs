org.litesoft.p2pchat.ActivePeerManager
