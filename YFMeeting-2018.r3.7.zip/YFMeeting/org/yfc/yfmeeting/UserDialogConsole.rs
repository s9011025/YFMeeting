org.litesoft.p2pchat.UserDialogConsole
