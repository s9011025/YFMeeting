org.litesoft.p2pchat.AbstractP2PChat$ArgsParser$AddressPort
org.litesoft.p2pchat.AbstractP2PChat$ArgsParser$DottedAddress
org.litesoft.p2pchat.AbstractP2PChat$ArgsParser
org.litesoft.p2pchat.AbstractP2PChat
