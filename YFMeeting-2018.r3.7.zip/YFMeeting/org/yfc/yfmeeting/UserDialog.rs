org.litesoft.p2pchat.UserDialog
