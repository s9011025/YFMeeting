org.litesoft.p2pchat.PendingPeerNode
