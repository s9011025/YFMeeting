org.litesoft.p2pchat.UserDialogAWT$1
org.litesoft.p2pchat.UserDialogAWT
org.litesoft.p2pchat.UserDialogAWT$2
org.litesoft.p2pchat.UserDialogAWT$3
org.litesoft.p2pchat.UserDialogAWT$4
