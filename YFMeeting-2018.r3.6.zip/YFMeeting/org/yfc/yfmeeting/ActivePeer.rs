org.litesoft.p2pchat.ActivePeer
org.litesoft.p2pchat.ActivePeer$NewPeersSupport
org.litesoft.p2pchat.ActivePeer$ActivePeersSupport
