org.litesoft.p2pchat.PendingPeerLinkedList
